Bootstrap to WordPress by Brad Hussey

Hope you enjoy the course :) Please leave a rating & review + share with your friends & colleagues.

Sign up for free and check out more of our courses at: CodeCollege.ca

Also, subscribe to my blog for a free 7-day freelancing crash course at: bradhussey.ca/subscribe

Cheers & Happy Coding!
Brad